# NeoAgent — Marketing Website

AI Receptionist & WhatsApp Automation for Clinics.

Built with **Next.js 15** (App Router) · **TypeScript** · **Tailwind CSS**.

## Pages

| Route              | Description                          |
| ------------------ | ------------------------------------- |
| `/`                 | Home — hero, features, benefits, FAQ, contact |
| `/privacy-policy`   | Privacy Policy                        |
| `/terms`            | Terms of Service                      |
| `/data-deletion`    | Data deletion request instructions    |
| `/contact`          | Contact form + direct email           |

Also included: `/sitemap.xml`, `/robots.txt`, and a dynamically generated Open Graph image.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Production build (what Vercel runs)

```bash
npm run build
npm run start
```

## Deploy — GitHub + Vercel

This repo is already git-initialized with one commit. To get it live:

### 1. Create the GitHub repo and push

```bash
# from the project folder
git remote add origin https://github.com/<your-username>/neoagent.git
git branch -M main
git push -u origin main
```

(Create the empty repo first at https://github.com/new — don't initialize it with a README, or pull before pushing.)

### 2. Deploy to Vercel

**Option A — Dashboard (no CLI, ~1 minute):**
1. Go to https://vercel.com/new
2. Import the `neoagent` GitHub repo you just pushed
3. Framework preset auto-detects as **Next.js** — leave defaults
4. Click **Deploy**

**Option B — CLI:**
```bash
npm i -g vercel
vercel login
vercel --prod
```

No environment variables are required — the site has no backend/database dependencies. The contact form opens a pre-filled email via `mailto:` rather than calling an API.

### 3. After first deploy

Update `siteUrl` in `app/layout.tsx`, `app/sitemap.ts`, and `app/robots.ts` from the placeholder `https://neoagent.vercel.app` to your actual production domain, then redeploy.

## Editing content

- Copy for every section lives directly in the matching component under `components/`.
- Legal page text lives in `app/privacy-policy/page.tsx`, `app/terms/page.tsx`, `app/data-deletion/page.tsx`.
- Contact email is set in one place per file — search for `neoagent.call@gmail.com` to update everywhere.
